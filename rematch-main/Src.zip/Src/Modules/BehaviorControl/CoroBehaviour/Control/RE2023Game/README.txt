This folder is an implementation of the RoboEireann 2023 game behaviour
