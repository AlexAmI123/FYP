This is an implementation of the RoboEireann 2019 behaviour
with bug fixes where appropriate